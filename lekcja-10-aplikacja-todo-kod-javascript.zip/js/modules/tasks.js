var tasks = [
	'Wynieść śmieci',
	'Pójść do sklepu',
	'Pobiegać',
	'Nauczyć się JavaScriptu!'
];